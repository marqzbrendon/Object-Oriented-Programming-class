/***************************************************************
 * File: rational.cpp
 * Author: Brendon Marques
 * Purpose: Contains the method implementations for the Rational class.
 ***************************************************************/

#include "rational.h"
#include <iostream>
#include <iomanip>
using namespace std;

// put your method bodies here
void Rational::prompt()
{
	cout << "Top: ";
	cin >> top;
	cout << "Bottom: ";
	cin >> bottom;
}

void Rational::display()
{
	cout << top 
		  << "/" 
		  << bottom
		  << endl;
}

void Rational::displayDecimal()
{
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);

	cout << float (top) / float (bottom)
	     << endl;
}

