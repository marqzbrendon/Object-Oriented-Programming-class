#ifndef rocks_h
#define rocks_h

#include "flyingObjects.h"

// Define the following classes here:
//   Rock
class Rock : public FlyingObjects
{
private:

public:

};



#endif /* rocks_h */
