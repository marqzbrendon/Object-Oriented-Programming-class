#include "rocks.h"

// Put your Rock methods here
void Rock::draw()
{
   drawLargeAsteroid(getPoint(), BIG_ROCK_SPIN);
}